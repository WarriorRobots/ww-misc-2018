/*----------------------------------------------------------------------------*/
/* Copyright (c) 2017-2018 FIRST. All Rights Reserved.                        */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package org.usfirst.frc.team2478.robot;

import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;

import edu.wpi.first.wpilibj.Counter;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.GenericHID.Hand;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.XboxController;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the build.properties file in the
 * project.
 */
public class Robot extends IterativeRobot {
	private WPI_TalonSRX boschMotor;
	private XboxController xbox;
	private Counter counterHi = new Counter(2);
	private double highPeriod;
	/**
	 * This function is run when the robot is first started up and should be
	 * used for any initialization code.
	 */
	@Override
	public void robotInit() {
		boschMotor = new WPI_TalonSRX(1);
		xbox = new XboxController(0);
		counterHi.setSemiPeriodMode(true);
	}

	@Override
	public void teleopInit() {
		counterHi.reset();
	}
	@Override
	public void teleopPeriodic() {
		boschMotor.set(xbox.getY(Hand.kLeft));
		highPeriod = counterHi.get();
		System.out.println("Encoder Count: " + Double.toString(highPeriod));
	}

}
